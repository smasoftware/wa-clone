Repo for project-based class.

The repo has branches for exercises and solutions.